# Selva Juego

Proyecto estático con HTML, CSS y JavaScript para la página "Selva del Saber".

Instrucciones rápidas para subir a GitHub y activar GitHub Pages:

1. Abrir terminal en la carpeta del proyecto (ej: `c:\Users\i7\Downloads\selva-juego`).

2. Inicializar git y hacer commit inicial:

```powershell
git init
git add .
git commit -m "Inicial: sitio Selva del Saber"
git branch -M main
```

3. Crear repositorio remoto en GitHub (desde la web o con la CLI `gh`):

Con `gh` (si está instalada e iniciada sesión):

```powershell
gh repo create NOMBRE-REPO --public --source=. --remote=origin --push
```

4. Activar GitHub Pages: en la página del repositorio ir a Settings → Pages y seleccionar la rama `main` (root). La URL será `https://<tu-usuario>.github.io/<NOMBRE-REPO>/`.

Si quieres, puedo ejecutar los comandos Git desde aquí (necesitarás autorizar), o guiarte paso a paso.
